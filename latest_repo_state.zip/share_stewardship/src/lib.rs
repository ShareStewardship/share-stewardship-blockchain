// lib.rs
pub mod dag_module;

// You can add initial unit tests here as well:
#[cfg(test)]
mod tests {
    #[test]
    fn basic_test() {
        assert_eq!(1 + 1, 2);
    }
}
